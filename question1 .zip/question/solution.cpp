#include<iostream>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include <unistd.h>
int main(int argc, char *argv[])
{
	 ios_base::sync_with_stdio(false);
    cin.tie(NULL);
 
    int *num = new int[50];
    for(int i=0; i<50; i++){
        num[i] = 0;
    }
    long long x = 1989349839349349;
    cout<<x;
    execl("question", "question",
          0);
          while(1){
          cout<<1<<endl;
          }
    }
